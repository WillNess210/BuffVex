#include "Constants.c"

//** HELPER FUNCS **\\
//** HELPER FUNCS **\\
//** HELPER FUNCS **\\
//** HELPER FUNCS **\\


// Give it a number of inches and it gives you the number of encoder tick's that you need
// to travel to travel that exact distance you gave it.
int getTicksFromDistance(float distInInches){
		return distInInches * ticksPerInch;
}

// Returns a number bounded by another number.
//You can pass in a number and bound it between (-128, 128) to make sure you're giving motors good powers
int bound(int value, int positivemaxmin){
		if(value < -positivemaxmin){
			return -positivemaxmin;
		}else if(value > positivemaxmin){
			return positivemaxmin;
		}else{
			return value;
		}
}

// Takes the difference between a goal and a sensor (Where you want to be minus where you're at) and multiplies it by a constant.
// This is then usually taken and applied to a motor. Called proportional control. Pass in current val, goal val, KP (usually a decimal)
// and a percentage of maximum power (-1.0 to 1.0)
int pidPower(int sensorVal, int goalVal, float kP, float maxPowerPercent){
	int maxPower = 127 * maxPowerPercent;
	int power = (goalVal - sensorVal) * kP;
	power = bound(power, 128 * maxPowerPercent);
	return (goalVal - sensorVal) * kP;
}

// Same this as the function above but it automatically caps at 40%
int pidPower(int sensorVal, int goalVal, float kP){
	return pidPower(sensorVal, goalVal, kP, 0.4);
}

// Drives all 4 motors based on left power and right power.
void Drive(int Lpower, int Rpower){ //input left and right power to drive
	motor[RightWide]  = Rpower;
	motor[RightCenter] = Rpower;
	motor[LeftWide]  = Lpower;
	motor[LeftCenter] = Lpower;
}

// Simple arcade drive function, used for driving in teleop.
void ArcadeDrive(int y, int x){
	Drive(y+x,y-x);
}

/*
// Use this to apply power to the arm.
void DriveArm(int Power){
	motor[LeftArm] = Power;
	motor[RightArm] = Power;
}

// Use this to apply power to the chainbars.
void DriveChainbar(int power){
	motor[LeftChainbar] = power;
	motor[RightChainbar] = power;
}

// Use this to apply power to the intake.
void DriveIntake(int power){
	motor[Intaker] = power;
}
*/

// Use this to apply power to the mobile deployer.
void DriveMobileGoal(int power){
	motor[MobileDeployer] = power;
}

// Use this to close the claw. Untested.
void CloseClaw(){
	SensorValue[ClawGrabber] = 0;
}

// Use this to open the claw. Untested.
void OpenClaw(){
	SensorValue[ClawGrabber] = 1;
}

// This function updates the variables that store sensor values. You should use these variables everywhere in the code
// and call this function before you use the variables!!!! If you ever need to flip a sign of the input, do it in
// this function!
void updateSensors(){
	quadValLeft = -SensorValue[LeftEncoder];
	quadValRight = -SensorValue[RightEncoder];
	armPotVal = SensorValue[ArmPot];
	angleVal = 0; // UPDATE THIS TO ANGLE ONCE WE GET GYRO WORKING
}

// Use this for putting arm where it should be based on cones
int getArmPos(){
	return armMobileGoal + (armConeStep * curCone);
}

// Use this for putting arm where it should hover at above the cones
int getArmPosHover(){
	return getArmPos() + armConeStep * 1; // arm pos for 1 cone above where it'll be dropping to
}

//** THINGS TO USE IN AUTO **\\
//** THINGS TO USE IN AUTO **\\
//** THINGS TO USE IN AUTO **\\
//** THINGS TO USE IN AUTO **\\

// You can use functions above as well, especially the OpenClaw() and CloseClaw() funcs

// Give this function a number of seconds to complete this command and the number of inches you wish to drive
// Always set the number of seconds to be too high and reduce it later.
void DriveStraight(float secondsToGive, float inches){
	updateSensors();
	int lgoal = quadValLeft + getTicksFromDistance(inches);
	int rgoal = quadValRight + getTicksFromDistance(inches);
	ClearTimer(T1);
	while(time1[T1] < secondsToGive * 1000){
		updateSensors();
		int leftPIDPower = pidPower(quadValLeft, lgoal, drivekP);
		int rightPIDPower = pidPower(quadValRight, rgoal, drivekP);
		Drive(leftPIDPower, rightPIDPower);
	}
	Drive(0, 0);
}

// Give this function a number of seconds to complete this command and the number of degrees you wish to turn
void TurnRobot(float secondsToGive, float angle){
	updateSensors();
	float agoal = angleVal + angle;
	ClearTimer(T1);
	while(time1[T1] < secondsToGive * 1000){
		updateSensors();
		int turnPow = pidPower(angleVal, agoal, turnkP);
		Drive(turnPow, -turnPow);
	}
	Drive(0, 0);
}

// Give this function a number of seconds to complete this command and the arm pot value you wish it to travel to
// Always set the number of seconds to be too high and reduce it later.
// LOL DUZN'T WORK
/*void RaiseArmTo(float secondsToGive, int setPoint){
	updateSensors();
	ClearTimer(T1);
	while(time1[T1] < secondsToGive * 1000){
		updateSensors();
		int armPower = -pidPower(armPotVal, setPoint, armkP, armSpeed);
		DriveArm(armPower);
	}
	DriveArm(0);
} */
/*
// This function drives the arm for a given number of seconds at a given power
void DriveArmFor(float seconds, int power){
	DriveArm(power);
	delay(seconds * 1000);
	DriveArm(0);
}

// Call this when you want to put the chainbar in the lower position
void LowerChainbar(){ // Confirmed works
	DriveChainbar(powerToLowerChainbar);
	delay(secondsToLowerChainbar * 1000);
	DriveChainbar(0);
}

// Call this when you want to put the chainbar in the upper position
void RaiseChainbar(){ // Confirmed works
	DriveChainbar(powerToRaiseChainbar);
	delay(secondsToRaiseChainbar * 1000);
	DriveChainbar(0);
}

// Call this to turn on the intake
void TurnOnIntake(){ // Confirmed works
	DriveIntake(intakeSpeed);
}

// Call this to outtake the cone
void TurnOnOuttake(){ // Confirmed works
	DriveIntake(outtakeSpeed);
}

// Call this to turn off intake/outtake
void TurnOffIntake(){ // Confirmed works
	DriveIntake(0);
}
*/
// Call this as a command to drop the cone.
/*
void OutTakeCone(){ // Confirmed works
	TurnOnOuttake();
	delay(secondsToOuttake * 1000);
	TurnOffIntake();
}
*/
// Call this as a command to deploy mobile goal
void DeployGoal(){ // Confirmed works
	DriveMobileGoal(deploySpeed);
	delay(deploySeconds * 1000);
	DriveMobileGoal(0);
}

// Call this as a command to recall mobile goal
void RecallGoal(){ // Confirmed works
	DriveMobileGoal(recallSpeed);
	delay(recallSeconds * 1000);
	DriveMobileGoal(0);
}

// Call this command when you're about to get a goal
// Opens the claw while deploying the grabber
void DeployAndOpen(){
	OpenClaw();
	DeployGoal();

}

// Call this command when you've already driven into the goal
// Closes claw and then pulls in the goal
void PickupGoal(){
	CloseClaw();
	delay(CloseClawSeconds);
	RecallGoal();
}

// Call this command when you want to drop off a mobile goal
void DropGoal(){
	DeployGoal();
	OpenClaw();
}


//** AUTOMATIC STACKING STUFF **\\
//** AUTOMATIC STACKING STUFF **\\
//** AUTOMATIC STACKING STUFF **\\
//** AUTOMATIC STACKING STUFF **\\

// resets how many cones you're carrying
/*
void resetConeCount(){
	curCone = 0;
}

// index's how many cones you're carrying
void indexConeCount(){
	curCone++;
}
// decerements how many cones you're carrying
void decrementConeCount(){
	curCone--;
}

// stacks a cone
// assumes that the chainbar is down, cone is right below intake
// no longer necessary
void stack(){
	// TURN ON INTAKE
	TurnOnIntake();
	// LOWER ARM
	RaiseArmTo(1, armConePickup);
	// TURN OFF INTAKE
	TurnOffIntake();
	// RAISE ARM TO A LITTLE ABOVE HEIGHT
	RaiseArmTo(1, getArmPosHover());
	// RAISE CHAINBAR
	RaiseChainbar();
	// LOWER ARM TO HEIGHT
	RaiseArmTo(1, getArmPos());
	// OUTTAKE
	OutTakeCone();
	// LOWER CHAINBAR
	LowerChainbar();
	// RESET ARM TO RESTING POSITION
	RaiseArmTo(1, armResting);
	// INDEX CONE COUNT
	indexConeCount();
} */

//** AUTO MODES **\\
//** AUTO MODES **\\
//** AUTO MODES **\\
//** AUTO MODES **\\

// DRIVES FORWARD, puts cone on stationary goal, backs up.
// All that ~should~ need to be changed is constants & times





/*
void StationaryGoal(){
	// RAISE ARM ABOVE STATIONARY GOAL
	// DriveArmFor(1, 30); // 1 second 30 power
	// DRIVE TO STATIONARY GOAL
	DriveStraight(5, inchesToStationaryGoal);
	// LOWER ARM JUST ABOVE STATIONARY GOAL
	// DriveArmFor(0.5, -30);
	// DEPLOY CHAINBAR
	//LowerChainbar();
	// OUTTAKE
	//OutTakeCone();
	// BACKUP
	DriveStraight(2, inchesToBackup);
}
*/




//** OLD CODE **\\
//** OLD CODE **\\
//** OLD CODE **\\
//** OLD CODE **\\

// OTHER THINGS TO MONITOR
/*


void StationaryGoal(){
	// RAISE ARM ABOVE STATIONARY GOAL
	RaiseArmTo(3, armStationaryGoal + armConeStep + armConeStep); // Raises arm to stationary goal + 2 cones worth above (in case it droops during drivetime)
	// DRIVE TO STATIONARY GOAL
	DriveStraight(5, inchesToStationaryGoal);
	// LOWER ARM JUST ABOVE STATIONARY GOAL
	RaiseArmTo(1, armStationaryGoal);
	// DEPLOY CHAINBAR
	LowerChainbar();
	// OUTTAKE
	OutTakeCone();
	// BACKUP
	DriveStraight(2, inchesToBackup);
	// LOWER ARM TO MOBILE GOAL HEIGHT
	RaiseArmTo(3, armResting);
}

void GrabMobileGoal(){
	// DRIVE TO MOBILE GOAL
	DriveStraight(7,inchesToMobileGoal);
	// RAISE ARM UP A BIT
	RaiseArmTo(2, armMobileGoal + armConeStep + armConeStep); // Raises arm to mobile goal + 2 cones worth above (incase of droop)
	// DEPLOY GRABBER
	DeployAndOpen();
	// ANGLE AT MOBILE GOAL
	TurnRobot(1, angleToFaceGoal);
	// DRIVE FORWARD
	DriveStraight(3,inchesFromTurn);
	// GRAB MOBILE GOAL & RECALL
	PickupGoal();
	// DRIVE BACKWARD
	DriveStraight(3, -inchesFromTurn);
	// ANGLE AGAIN
	TurnRobot(1, -angleToFaceGoal);
	// LOWER ARM
	RaiseArmTo(2, armMobileGoal);
	// DROP CONE
	OutTakeCone();
	// RAISE ARM SLIGHTLY
	RaiseArmTo(2, armMobileGoal + armConeStep + armConeStep);
	// DRIVE BACKWARD TO START
	DriveStraight(7, -inchesToMobileGoal);
	// TURN 180
	TurnRobot(2, 180);
	// DRIVE FORWARD
	DriveStraight(4, inchesToDeployment);
	// OPEN CLAW & DEPLOY
	DropGoal();
	// DRIVE BACKWARD
	DriveStraight(4, -inchesToDeployment);
	// RECALL GRABBER
	RecallGoal();
}





task robot_tasks()
{
	while (true)
	{
		if(driveFlag == PIDCONTROL){
			goalValue = getTicksFromDistance(18);
			leftDrive = pidPower(quadValLeft, goalValue, 0.15, 0.6);
			rightDrive = pidPower(quadValRight, goalValue, 0.15, 0.6);
			Drive(leftDrive, rightDrive);
		}
		delay(10);
	}
} */
