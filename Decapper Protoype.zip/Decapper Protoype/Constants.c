// DOPE ENCODER MATH WOOO
float ticksPerRev = 360.0;
float wheelDiameter = 4.0;
float wheelCircumference = wheelDiameter * 3.1415;
float ticksPerInch = ticksPerRev/wheelCircumference;
// END OF DOPE ENCODER MATH WOOO

// GLOBAL CONSTANTS TO DISPLAY
int quadValLeft = 0;
int quadValRight = 0;
int armPotVal = 0;
int angleVal = 0;
//


// DRIVE CONSTANTS
float drivekP = 0.5; // raise if it's not getting close enough, lower if it's too jerky
float turnkP = 3;
//

// ARM CONSTANTS
int armBottom = 15; // arm pot value displayed when arm is at minimum position
int armConePickup = 16; // arm pot value displayed when arm is picking up a cone
int armMobileGoal = 18; // arm pot value displayed when arm is at mobile goal (position where you'd want to drop first cone at)
int armTop = 34; // arm pot value at the maximum height (I'd recommend a bit lower than the actual maximum) Use the practical maximum not the physical maximum
int armStationaryGoal = 25; // arm pot value of where you want to drop on the stationary goal from
int armHumanload = 20; // arm pot val of where you want to pickup from the human load from
int armResting = 20; // arm pot val when arm is resting. Robot will use this for driving position.
int armConeStep = 3; // arm pot value inbetween cones. To calculate, take (arm pot value when depositing cone #2 on mobile goal) - (arm pot value when depositing cone #1 on mobile goal)
float armkP = 3; // raise if it's not getting close enough, lower if it's too jerky
float armSpeed = 0.3; // Give number between 0.0 and 1.0 (1.0 is full speed, 0.0 is no speed) (cap % for arm power for PID)
//

// ARM CONE COUNTING
int curCone = 0;
//

// CHAINBAR CONSTANTS
float secondsToRaiseChainbar = 0.8; // ENTER NUMBER OF SECONDS YOU WANT RAISE CHAINBAR COMMAND TO TAKE
int powerToRaiseChainbar = 100; // ENTER POWER YOU WISH TO DRIVE CHAINBAR AT DURING THIS COMMAND (0 to 128) (FLIP SIGN IF WRONG DIRECTION)

float secondsToLowerChainbar = 1; // ENTER NUMBER OF SECONDS YOU WANT LOWER CHAINBAR COMMAND TO TAKE
int powerToLowerChainbar = -50; // ENTER POWER YOU WISH TO DRIVE CHAINBAR AT DURING THIS COMMAND (-128 to 0) (FLIP SIGN IF WRONG DIRECTION)
//

// INTAKE/OUTTAKE CONSTANTS
int intakeSpeed = 80; // Power for intake command to run at (0 to 128) (FLIP SIGN IF WRONG DIRECTION)
int outtakeSpeed = -80; // Power for outtake command to run at (-128 to 0) (FLIP SIGN IF WRONG DIRECTION)
float secondsToOuttake = 0.5;
//

// MOBILE GOAL CONSTANTS
int deploySpeed = 100; // Power to deploy mobile goal (0 to 128) (FLIP SIGN IF WRONG DIRECTION)
float deploySeconds = 1; // Seconds to deploy mobile goal for
int recallSpeed = -128; // Power to recall mobile goal (-128 to 0) (FLIP SIGN IF WRONG DIRECTION)
float recallSeconds = 1; // Seconds to recall mobile goal for
float CloseClawSeconds = 1; // Seconds to wait for claw to close
//

// AUTO DISTANCE CONSTANTS
float inchesToStationaryGoal = 12;
float inchesToBackup = -6;

float inchesToMobileGoal = 0;
float inchesFromTurn = 0;
float inchesToDeployment = 0;

float angleToFaceGoal = 15;
//
