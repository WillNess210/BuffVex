// Contains basic drive helper functions for Tesla Demo

void updateSensors(){
	quadValLeft = -SensorValue[LeftEncoder];
	quadValRight = -SensorValue[RightEncoder];
	//armPotVal = SensorValue[ArmPot];
	//angleVal = 0; // UPDATE THIS TO ANGLE ONCE WE GET GYRO WORKING
}

void Drive(int Lpower, int Rpower){ //input left and right power to drive
	motor[RightWide]  = Rpower;
	motor[RightCenter] = Rpower;
	motor[LeftWide]  = Lpower;
	motor[LeftCenter] = Lpower;
}

void ArcadeDrive(int y, int x){
	Drive(y+x,y-x);
}

void CloseClaw(){
	SensorValue[ClawGrabber] = 0;
}

void OpenClaw(){
	SensorValue[ClawGrabber] = 1;
}

void StationaryGoal(){
	DriveStraight(5, inchesToStationaryGoal);
	DriveStraight(2, inchesToBackup);
}
